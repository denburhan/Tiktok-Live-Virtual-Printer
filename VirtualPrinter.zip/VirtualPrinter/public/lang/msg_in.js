var MSG_GIFT = "terimaakasyy kepaadaa |username| yank uhdaa kirim gift";
var MSG_WINNER = "selaamaat kepaadaa |username| kaarenaa berhasyl menebaak jaawaabaan haa haa haaa";
var MSG_TEST = "TEST SOOWAARAA";